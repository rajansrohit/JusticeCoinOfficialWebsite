# Justice Coin

JusticeCoin is a blockchain based mining scheme which harnesses distributed computing power to generate revenue for non-profits supporting economic and social justice

This decentralized mining application serves to allow everyday laptops and computers to help empower economic and social justice

## Installation and Development

Install required dependencies and libraries:
```yarn install```

Start app:
```yarn start```

Accept all permissions if necessary
