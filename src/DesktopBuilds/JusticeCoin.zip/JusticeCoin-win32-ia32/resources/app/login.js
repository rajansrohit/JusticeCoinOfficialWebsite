var open = require("open");
open("https://tinyurl.com/5gqnj");